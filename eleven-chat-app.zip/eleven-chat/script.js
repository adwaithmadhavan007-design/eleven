document.addEventListener('DOMContentLoaded', () => {
    // --- Data & State ---
    const friends = [
        { id: 'mike', name: 'Mike Wheeler', status: 'online' },
        { id: 'dustin', name: 'Dustin Henderson', status: 'online' },
        { id: 'lucas', name: 'Lucas Sinclair', status: 'offline' },
        { id: 'will', name: 'Will Byers', status: 'online' },
        { id: 'max', name: 'Max Mayfield', status: 'offline' }
    ];

    let powerLevel = 5; // Starts at 5%
    const POWER_DECAY = 2; // Amount power decreases per interval
    const DECAY_INTERVAL = 3000; // 3 seconds

    // --- DOM Elements ---
    const friendsListEl = document.getElementById('friendsList');
    const chatHistoryEl = document.getElementById('chatHistory');
    const chatInputEl = document.getElementById('chatInput');
    const sendBtnEl = document.getElementById('sendBtn');
    const powerMeterFillEl = document.getElementById('powerMeterFill');
    const powerStatusTextEl = document.getElementById('powerStatusText');

    // --- Initialization ---
    initFriendsList();
    updatePowerUI();

    // --- Event Listeners ---
    sendBtnEl.addEventListener('click', handleSendMessage);
    chatInputEl.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleSendMessage();
        }
    });

    // Simulated responses
    setTimeout(() => {
        receiveMessage('Mike Wheeler', 'El? Are you there?');
    }, 2000);

    // Power decay loop
    setInterval(() => {
        if (powerLevel > 5) {
            powerLevel = Math.max(5, powerLevel - POWER_DECAY);
            updatePowerUI();
        }
    }, DECAY_INTERVAL);

    // --- Functions ---

    function initFriendsList() {
        friendsListEl.innerHTML = '';
        friends.forEach(friend => {
            const li = document.createElement('li');
            li.className = 'friend-item';

            const statusIndicator = document.createElement('div');
            statusIndicator.className = `friend-status ${friend.status}`;

            const nameEl = document.createElement('span');
            nameEl.className = 'friend-name';
            nameEl.textContent = friend.name;

            li.appendChild(statusIndicator);
            li.appendChild(nameEl);
            friendsListEl.appendChild(li);
        });
    }

    function getTimestamp() {
        const now = new Date();
        const hrs = String(now.getHours()).padStart(2, '0');
        const mins = String(now.getMinutes()).padStart(2, '0');
        return `[${hrs}:${mins}]`;
    }

    function handleSendMessage() {
        const text = chatInputEl.value.trim();
        if (!text) return;

        // 1. Add message to UI
        appendMessage('Eleven', text, 'sent');

        // 2. Clear input
        chatInputEl.value = '';

        // 3. Increase Power Level! The more you chat, the higher it goes.
        // Base increase + bonus for message length
        const increase = 15 + Math.min(20, Math.floor(text.length / 2));
        powerLevel = Math.min(100, powerLevel + increase);
        updatePowerUI();

        // 4. Simulate a response occasionally
        if (Math.random() > 0.4) {
            setTimeout(() => {
                const onlineFriends = friends.filter(f => f.status === 'online');
                if (onlineFriends.length > 0) {
                    const randomFriend = onlineFriends[Math.floor(Math.random() * onlineFriends.length)];
                    const responses = [
                        "Copy that.",
                        "Is it safe?",
                        "Meet at the quarry.",
                        "I hear you, El.",
                        "Over and out.",
                        "Are they coming?",
                        "Friends don't lie.",
                        "Did you find him?"
                    ];
                    const randomResponse = responses[Math.floor(Math.random() * responses.length)];
                    receiveMessage(randomFriend.name, randomResponse);
                }
            }, 1000 + Math.random() * 2000);
        }
    }

    function receiveMessage(sender, text) {
        appendMessage(sender, text, 'received');
        // Minor power bump on receiving messages
        powerLevel = Math.min(100, powerLevel + 5);
        updatePowerUI();
    }

    function appendMessage(sender, text, type) {
        const msgDiv = document.createElement('div');
        msgDiv.className = `message ${type}`;

        let innerHTML = `<span class="timestamp">${getTimestamp()}</span>`;
        if (type === 'received') {
            innerHTML += `<span class="sender-name">${sender}</span>`;
        }

        // Typewriter effect container
        innerHTML += `<span class="msg-text"></span>`;
        msgDiv.innerHTML = innerHTML;
        chatHistoryEl.appendChild(msgDiv);

        // Scroll to bottom
        chatHistoryEl.scrollTop = chatHistoryEl.scrollHeight;

        // Animate text if received or system
        const textSpan = msgDiv.querySelector('.msg-text');
        if (type !== 'sent') {
            let i = 0;
            const speed = 50; // ms per character
            function typeWriter() {
                if (i < text.length) {
                    textSpan.textContent += text.charAt(i);
                    i++;
                    chatHistoryEl.scrollTop = chatHistoryEl.scrollHeight;
                    setTimeout(typeWriter, speed + (Math.random() * 30));
                }
            }
            typeWriter();
        } else {
            textSpan.textContent = text;
            chatHistoryEl.scrollTop = chatHistoryEl.scrollHeight;
        }
    }

    function updatePowerUI() {
        // Handle responsive horizontal meter logic via CSS transition
        // But for vertical or horizontal, setting width/height style needs checking or we just set --power variable
        // Let's implement height for desktop, and width change for mobile via inline style overrides or CSS variable

        if (window.innerWidth <= 900) {
            powerMeterFillEl.style.height = '100%';
            powerMeterFillEl.style.width = `${powerLevel}%`;
        } else {
            powerMeterFillEl.style.width = '100%';
            powerMeterFillEl.style.height = `${powerLevel}%`;
        }

        // Add surge effect if power is high
        if (powerLevel >= 85) {
            powerMeterFillEl.classList.add('surge');
        } else {
            powerMeterFillEl.classList.remove('surge');
        }

        // Update Text
        if (powerLevel <= 20) {
            powerStatusTextEl.textContent = 'CRITICAL LOW';
            powerStatusTextEl.style.color = '#ff1744';
        } else if (powerLevel <= 50) {
            powerStatusTextEl.textContent = 'STABLE';
            powerStatusTextEl.style.color = '#ff9800';
        } else if (powerLevel <= 85) {
            powerStatusTextEl.textContent = 'GROWING';
            powerStatusTextEl.style.color = '#00e676';
        } else {
            powerStatusTextEl.textContent = 'MAXIMUM CAPACITY';
            powerStatusTextEl.style.color = '#e040fb'; // Neon purple/pink for max power
        }
    }

    // Handle window resize for the power meter styles
    window.addEventListener('resize', () => {
        // Reset styles to allow updatePowerUI to re-apply the correct dimension
        powerMeterFillEl.style.height = '';
        powerMeterFillEl.style.width = '';
        updatePowerUI();
    });

    // Clear initial system message to apply typewriter effect correctly
    chatHistoryEl.innerHTML = '';
    appendMessage('SYSTEM', 'Session started. Awaiting input.', 'system');
});
