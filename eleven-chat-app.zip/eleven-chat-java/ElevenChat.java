import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.DefaultCaret;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class ElevenChat extends JFrame {
    private Color bgDark = new Color(5, 5, 5);
    private Color panelBg = new Color(20, 10, 10);
    private Color textLight = new Color(224, 224, 224);
    private Color glowRed = new Color(255, 60, 60);
    private Color glowBlue = new Color(68, 138, 255);
    private Color borderColor = new Color(255, 82, 82, 100);

    private Font mainFont = new Font("Courier New", Font.PLAIN, 14);
    private Font boldFont = new Font("Courier New", Font.BOLD, 14);
    private Font headerFont = new Font("Courier New", Font.BOLD, 18);

    private int powerLevel = 5;
    private JPanel powerFill;
    private JLabel powerStatusLbl;
    private JTextPane chatHistory;
    private JTextField chatInput;
    private Random random = new Random();

    public ElevenChat() {
        setTitle("Eleven's Comm (Java Edition)");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(bgDark);
        setLayout(new BorderLayout(10, 10));
        ((JPanel)getContentPane()).setBorder(new EmptyBorder(10, 10, 10, 10));

        // 1. Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(panelBg);
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(borderColor, 2),
                new EmptyBorder(10, 20, 10, 20)
        ));
        
        JLabel brandLabel = new JLabel("ELEVEN_POV", SwingConstants.LEFT);
        brandLabel.setFont(new Font("Courier New", Font.BOLD, 24));
        brandLabel.setForeground(glowRed);
        
        JLabel statusLabel = new JLabel("● Uplink Established", SwingConstants.RIGHT);
        statusLabel.setFont(boldFont);
        statusLabel.setForeground(glowBlue);
        
        headerPanel.add(brandLabel, BorderLayout.WEST);
        headerPanel.add(statusLabel, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        // 2. Main Content
        JPanel mainContent = new JPanel(new BorderLayout(10, 10));
        mainContent.setOpaque(false);

        mainContent.add(createLeftSidebar(), BorderLayout.WEST);
        mainContent.add(createChatArea(), BorderLayout.CENTER);
        mainContent.add(createRightSidebar(), BorderLayout.EAST);

        add(mainContent, BorderLayout.CENTER);

        // Power decay timer
        Timer decayTimer = new Timer(3000, e -> {
            if (powerLevel > 5) {
                powerLevel = Math.max(5, powerLevel - 2);
                updatePowerUI();
            }
        });
        decayTimer.start();
        
        updatePowerUI();
    }

    private JPanel createLeftSidebar() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        stylePanel(panel);
        panel.setPreferredSize(new Dimension(220, 0));

        JLabel title = new JLabel("CONNECTIONS", SwingConstants.CENTER);
        title.setFont(headerFont);
        title.setForeground(glowRed);
        title.setBorder(new MatteBorder(0, 0, 1, 0, borderColor));
        panel.add(title, BorderLayout.NORTH);

        JPanel friendsPanel = new JPanel();
        friendsPanel.setLayout(new BoxLayout(friendsPanel, BoxLayout.Y_AXIS));
        friendsPanel.setOpaque(false);

        String[] friends = {"Mike Wheeler", "Dustin Henderson", "Lucas Sinclair", "Will Byers", "Max Mayfield"};
        boolean[] online = {true, true, false, true, false};

        for (int i = 0; i < friends.length; i++) {
            JPanel fPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
            fPanel.setOpaque(false);
            fPanel.setMaximumSize(new Dimension(200, 30));
            
            JLabel dot = new JLabel("●");
            dot.setForeground(online[i] ? new Color(0, 230, 118) : new Color(255, 23, 68));
            
            JLabel name = new JLabel(friends[i]);
            name.setFont(mainFont);
            name.setForeground(textLight);
            
            fPanel.add(dot);
            fPanel.add(name);
            friendsPanel.add(fPanel);
        }

        panel.add(friendsPanel, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createChatArea() {
         JPanel panel = new JPanel(new BorderLayout(0, 10));
         stylePanel(panel);

         chatHistory = new JTextPane();
         chatHistory.setEditable(false);
         chatHistory.setBackground(new Color(15, 10, 10));
         chatHistory.setForeground(textLight);
         chatHistory.setFont(mainFont);
         
         // Fix auto scroll
         DefaultCaret caret = (DefaultCaret)chatHistory.getCaret();
         caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

         JScrollPane scroll = new JScrollPane(chatHistory);
         scroll.setBorder(new LineBorder(new Color(255,255,255,30)));
         scroll.getVerticalScrollBar().setBackground(bgDark);
         panel.add(scroll, BorderLayout.CENTER);

         JPanel inputPanel = new JPanel(new BorderLayout(10, 0));
         inputPanel.setOpaque(false);

         chatInput = new JTextField();
         chatInput.setBackground(new Color(15, 15, 15));
         chatInput.setForeground(textLight);
         chatInput.setCaretColor(textLight);
         chatInput.setFont(mainFont);
         chatInput.setBorder(BorderFactory.createCompoundBorder(
             new LineBorder(borderColor),
             new EmptyBorder(5, 5, 5, 5)
         ));
         chatInput.addActionListener(e -> sendMessage());

         JButton sendBtn = new JButton("SEND");
         sendBtn.setBackground(bgDark);
         sendBtn.setForeground(glowRed);
         sendBtn.setFont(boldFont);
         sendBtn.setBorder(BorderFactory.createCompoundBorder(
             new LineBorder(glowRed),
             new EmptyBorder(5, 15, 5, 15)
         ));
         sendBtn.setFocusPainted(false);
         sendBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
         sendBtn.addActionListener(e -> sendMessage());

         inputPanel.add(chatInput, BorderLayout.CENTER);
         inputPanel.add(sendBtn, BorderLayout.EAST);

         panel.add(inputPanel, BorderLayout.SOUTH);
         
         appendSystemMessage("Session started. Awaiting input.");
         
         return panel;
    }

    private JPanel createRightSidebar() {
        JPanel panel = new JPanel(new BorderLayout());
        stylePanel(panel);
        panel.setPreferredSize(new Dimension(200, 0));

        JLabel title = new JLabel("POWER LEVEL", SwingConstants.CENTER);
        title.setFont(headerFont);
        title.setForeground(glowRed);
        title.setBorder(new MatteBorder(0, 0, 1, 0, borderColor));
        panel.add(title, BorderLayout.NORTH);

        // Meter container
        JPanel meterContainer = new JPanel(new GridBagLayout());
        meterContainer.setOpaque(false);

        JPanel meterBg = new JPanel(null);
        meterBg.setPreferredSize(new Dimension(40, 400));
        meterBg.setBackground(new Color(0, 0, 0, 200));
        meterBg.setBorder(new LineBorder(new Color(50, 50, 50), 2, true));

        powerFill = new JPanel();
        powerFill.setBackground(glowRed);
        meterBg.add(powerFill);

        meterContainer.add(meterBg);
        
        panel.add(meterContainer, BorderLayout.CENTER);

        powerStatusLbl = new JLabel("CRITICAL LOW", SwingConstants.CENTER);
        powerStatusLbl.setFont(boldFont);
        powerStatusLbl.setForeground(glowRed);
        powerStatusLbl.setBorder(new EmptyBorder(10,0,0,0));
        panel.add(powerStatusLbl, BorderLayout.SOUTH);

        return panel;
    }

    private void stylePanel(JPanel panel) {
        panel.setBackground(panelBg);
        panel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(borderColor),
            new EmptyBorder(15, 15, 15, 15)
        ));
    }

    private void sendMessage() {
        String text = chatInput.getText().trim();
        if (text.isEmpty()) return;

        appendMessage("Eleven", text, true);
        chatInput.setText("");

        // Increase power
        int increase = 15 + Math.min(20, text.length() / 2);
        powerLevel = Math.min(100, powerLevel + increase);
        updatePowerUI();

        if (random.nextDouble() > 0.4) {
            Timer replyTimer = new Timer(1000 + random.nextInt(2000), e -> {
                String[] msgs = {"Copy that.", "Is it safe?", "Meet at the quarry.", "Over and out.", "Friends don't lie.", "I hear you, El."};
                appendMessage("Mike Wheeler", msgs[random.nextInt(msgs.length)], false);
                powerLevel = Math.min(100, powerLevel + 5);
                updatePowerUI();
            });
            replyTimer.setRepeats(false);
            replyTimer.start();
        }
    }

    private void appendSystemMessage(String msg) {
        String time = new SimpleDateFormat("[HH:mm:ss]").format(new Date());
        try {
            javax.swing.text.Document doc = chatHistory.getDocument();
            doc.insertString(doc.getLength(), time + " " + msg + "\n\n", null);
        } catch (Exception e) {}
    }

    private void appendMessage(String sender, String text, boolean isSent) {
        String time = new SimpleDateFormat("[HH:mm]").format(new Date());
        try {
            javax.swing.text.Document doc = chatHistory.getDocument();
            doc.insertString(doc.getLength(), time + " " + sender + ":\n" + text + "\n\n", null);
        } catch (Exception e) {}
    }

    private void updatePowerUI() {
        SwingUtilities.invokeLater(() -> {
            int height = (int) (400 * (powerLevel / 100.0));
            powerFill.setBounds(0, 400 - height, 40, height);

            if (powerLevel <= 20) {
                powerStatusLbl.setText("CRITICAL LOW");
                powerStatusLbl.setForeground(new Color(255, 23, 68));
                powerFill.setBackground(new Color(255, 23, 68));
            } else if (powerLevel <= 50) {
                powerStatusLbl.setText("STABLE");
                powerStatusLbl.setForeground(new Color(255, 152, 0));
                powerFill.setBackground(new Color(255, 152, 0));
            } else if (powerLevel <= 85) {
                powerStatusLbl.setText("GROWING");
                powerStatusLbl.setForeground(new Color(0, 230, 118));
                powerFill.setBackground(new Color(0, 230, 118));
            } else {
                powerStatusLbl.setText("MAXIMUM CAPACITY");
                powerStatusLbl.setForeground(new Color(224, 64, 251));
                powerFill.setBackground(new Color(224, 64, 251));
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            } catch (Exception e) {}
            new ElevenChat().setVisible(true);
        });
    }
}
